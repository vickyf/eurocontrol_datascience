a = -4
if a<0:
    print('a is negative')
elif a==0:
    print('a is zero')
else:
    print('a is positive')