first_name = "John"
last_name = "Doe"
print(first_name + " " + last_name)