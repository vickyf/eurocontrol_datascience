JD=set('John Doe')
print(JD)
print(len(JD))
print('e' in JD)