empnb = {'Brussels': 200, 'London': 52, 'New York': 45, 'Bejing': 20}
cities=[x for x in empnb if empnb[x]>=30]
print(cities)