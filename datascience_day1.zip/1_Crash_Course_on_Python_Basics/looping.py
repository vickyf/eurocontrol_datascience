a=1
fact = 1
while a<=7:
    fact *= a
    a += 1
print(fact)