import math as m
print(round(m.pi,4))