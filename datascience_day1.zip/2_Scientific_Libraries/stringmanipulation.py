a = "John"
b = "Doe"
print(a + ' ' + b)