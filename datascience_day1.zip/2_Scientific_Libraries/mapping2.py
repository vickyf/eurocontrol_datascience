cdystonia2.treat.replace({'Placebo': 0, '5000U': 1, '10000U': 2}, inplace=True)
