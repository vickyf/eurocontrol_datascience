new_order = np.random.permutation(len(segments))
new_order[:30]