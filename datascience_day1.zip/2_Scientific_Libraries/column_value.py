print(data['value'])
print(data.value)