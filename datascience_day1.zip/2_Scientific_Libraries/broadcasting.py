import numpy as np
A = np.ones((3,3))
v = np.array([1,0,1])
A = A + v
print(A)