bacteria[[name.endswith('bacteria') for name in bacteria.index]]
