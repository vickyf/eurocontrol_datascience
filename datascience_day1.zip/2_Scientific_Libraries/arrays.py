import numpy as np
a = np.array([[-1,4.5,5],[4,6,7]])
print(a)
print(a.shape)