import numpy as np

print(np.zeros((5,6)))
print()
print(np.ones((2,1)))
print()
print(np.full((5,3),4))
print()
print(np.identity(3))
print()
print(np.random.random((3,4)))
print()
print(np.linspace(0,10,11))