hits['womacto01CHN2006':'gonzalu01ARI2006'] = 5
hits