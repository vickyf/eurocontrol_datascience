baseball = pd.read_csv("data/baseball.csv", index_col='id')
baseball.head(15)