cdystonia['treatment'] = cdystonia.treat.map(treatment_map)
cdystonia.treatment