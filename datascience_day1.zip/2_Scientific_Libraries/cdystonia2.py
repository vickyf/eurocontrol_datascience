cdystonia2 = cdystonia.set_index(['patient','obs'])
cdystonia2.head()
