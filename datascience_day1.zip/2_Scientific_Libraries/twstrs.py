twstrs_wide = cdystonia2['twstrs'].unstack('obs')
twstrs_wide.head()